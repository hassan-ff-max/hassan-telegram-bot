
module.exports = {
    mainToken: '8877474987:AAEMp4RaSpEXLecVcAGGSGzXxYTf1Oi63hQ', // Bot Token Here 
    
    S7: 'HASSAN FF BUG', // Owner, Name
    
    adminId: '8558373429', // Owner Chat ID ( control /address, /delresell )
    
    channel: 'https://t.me/hassan1H2S3N', // TG channel link
    
    group: 'https://t.me/+DLJQBGFDca00MTJk', // TG group link
    
    bot: 'HASSAN FF BUG', // Bot name 
    
    logo: './SY/Loves.jpg' // Bot logo path or URL
};